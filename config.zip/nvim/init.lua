-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")
vim.opt.laststatus = 0
vim.opt.guicursor = ""
vim.g.autoformat = false
vim.opt.mouse = ""
--
