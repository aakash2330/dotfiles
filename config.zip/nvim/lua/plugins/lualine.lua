return {
  "nvim-lualine/lualine.nvim",
  enabled = false,
}
