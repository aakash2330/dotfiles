return {
  "nvim-neo-tree/neo-tree.nvim",
  opts = {
    filesystem = {
      window = {
        auto_expand_width = false,
      },
    },
  },
}
