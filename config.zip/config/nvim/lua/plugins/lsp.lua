return {
  {
    "neovim/nvim-lspconfig",
    dependencies = {
      "prisma/vim-prisma",
    },
  },
}


