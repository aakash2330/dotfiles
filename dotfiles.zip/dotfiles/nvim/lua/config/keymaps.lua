-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here


vim.keymap.set("n", "<up>", "<nop>")
vim.keymap.set("n", "<down>", "<nop>")
vim.keymap.set("n", "<left>", "<nop>")
vim.keymap.set("n", "<right>", "<nop>")

vim.keymap.set("i", "<up>", "<nop>")
vim.keymap.set("i", "<down>", "<nop>")


vim.keymap.set("n", "<C-d>", "<C-d>zz")
vim.keymap.set("n", "<C-u>", "<C-u>zz")

vim.keymap.set("n", "n", "nzzzv")
vim.keymap.set("n", "N", "Nzzzv")


vim.keymap.set("i", "<A-j>", "<nop>")
vim.keymap.set("i", "<A-k>", "<nop>")
vim.keymap.set("i", "<A-j>", "<nop>")
vim.keymap.set("n", "<A-k>", "<nop>")


vim.keymap.set("x", "<A-j>", "<nop>")
vim.keymap.set("x", "<A-k>", "<nop>")

vim.keymap.set("x", "J", "<nop>")
vim.keymap.set("x", "K", "<nop>")



